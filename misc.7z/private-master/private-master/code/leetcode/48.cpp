#include <iostream>
#include <vector>
using namespace std;

class Solution {
public:
    // #r round(from 0): (r, r) ~ (r, n-2-r)
    void rotate(vector<vector<int>>& m, int r) {
        int n = m.size();
        for (int j = r; j <= n-2-r; ++j) {
            int temp = m[r][j];
            m[r][j] = m[n-1-j][r];
            m[n-1-j][r] = m[n-1-r][n-1-j];
            m[n-1-r][n-1-j] = m[j][n-1-r];
            m[j][n-1-r] = temp;
        }
    }

    void rotate(vector<vector<int>>& m) {

        int i = 0;
        int n = m.size(); // m.size() -2 can produce very large number!!
        while (i <= n-2-i) {
            // (i, i) to (i, n-2-i)
            rotate(m, i++);
        }
    }
};


int main()
{
    vector<vector<int>> m = {{1,2,3,4},{5,6,7,8},{9,10,11,12},{13,14,15,16}};
    //vector<vector<int>> m = {{1,2,3},{4,5,6},{7,8,9}};
    //vector<vector<int>> m = {{1, 2}, {3, 4}};
    //vector<vector<int>> m = {{1}};
    Solution so;
    so.rotate(m);

    for (auto &i : m){
        for (auto &j : i) {
            cout << j << " ";
        }
        cout << endl;
    }

    return 0;

}

