#include <iostream>
#include <vector>
using namespace std;

/*
 * Recursion version
class Solution {
   public:
      vector<int> searchRange(vector<int>& nums, int target) {
         return searchRange(nums, 0, nums.size()-1, target);
      }

   private:
      vector<int> searchRange(
            vector<int>& nums,
            int low,
            int high,
            int target) {

         const vector<int> kNotFound = {-1, -1};

         if (low > high) {
            return kNotFound;
         }

         if (low == high) {
            return (nums[low] == target) ? vector<int>(2, low) : kNotFound;
         }

         int mid = (low + high) / 2;
         if (nums[mid] < target) {
            return searchRange(nums, mid+1, high, target);
         }
         else if (nums[mid] > target) {
            return searchRange(nums, low, mid-1, target);
         }
         else {
            // Don't forget to initialize!
            vector<int> l = kNotFound, r = kNotFound;

            // Do a quick right-look
            // mid+1 is always valid!
            if (nums[mid+1] == target) {
               r = searchRange(nums, mid+1, high, target);
            }
            
            // Do a quick left-peek
            // Make sure @mid is (signed) int. Otherwise, mid-1 >= 0 is always true!
            if ((mid-1 >= 0) && (nums[mid-1] == target)) {
               l = searchRange(nums, low, mid-1, target);
            }

            vector<int> res(2);
            res[0] = ((l[0] != -1) ? l[0] : mid);
            res[1] = ((r[1] != -1) ? r[1] : mid);
            return res;
         }
      }
};
*/

class Solution {
   public:
      vector<int> searchRange(vector<int>& nums, int target) {
         int low = 0, high = nums.size() - 1;
         int left = -1, right = -1;

         while (low <= high) {
            int mid = (low + high) / 2;
            if (nums[mid] > target) {
               high = mid - 1;
            }
            else if (nums[mid] < target) {
               low = mid + 1;
            }
            else {
               left = right = mid;
               int high_t = high, mid_t = mid;

               // Scan left [low, mid-1]
               high = mid - 1;
               while (low <= high) {
                  int mid = (low + high) / 2;
                  if (nums[mid] == target) {
                     left = mid;
                     high = mid - 1;
                  }
                  else {
                     low = mid + 1;
                  }
               }

               // Scan right [mid+1, high]
               low = mid_t + 1, high = high_t;
               while (low <= high) {
                  int mid = (low + high) / 2;
                  if (nums[mid] == target) {
                     right = mid;
                     low = mid + 1;
                  }
                  else {
                     high = mid - 1;
                  }
               }
            }
         }

         vector<int> res(2);
         res[0] = left;
         res[1] = right;

         return res;
      }
};

int main()
{
   Solution so;
   vector<int> nums = {1, 3, 3, 3, 3};
   //vector<int> nums = {1, 3, 3, 4, 5};
   vector<int> res = so.searchRange(nums, 3);
   cout << res[0] << ", " << res[1] << endl;
   return 0;
}
