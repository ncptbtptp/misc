#include <iostream>
#include <vector>
#include <string>

using namespace std;

// Backtracking.
// Basic concept is to fill all open braces '(', and what's left is ')'.
// We treat ')' as "holes" in code.
// When we place '(', make sure it's a valid place. i.e., make sure the room("holes")
// it leaves on its left for ')' is valid. (Can we put that many holes to match the
// previous '('?).
// There is a much cleaner way, based on binary tree? See below: 
// https://discuss.leetcode.com/topic/36057/easy-java-solution/2
class Solution {
public:
    vector<string> generateParenthesis(int n) {
        string s(2*n, ')');
        helper(s, 0, 0, n);
        return m_res;
    }

private:
    void helper(string &s, int offset, int sum, int stepsLeft) {
        // Try possible places to put a new '(' w/o conflicts.
        // Valid range: [offset, offset + sum]
        for (int i = 0; i <= sum; ++i) {

            // Put '(' at s[offset + i]
            s[offset + i] = '(';

            // Last step
            if (stepsLeft == 1) {
                m_res.push_back(s);
            }
            else {
                helper(s, offset + i + 1, sum + 1 - i, stepsLeft - 1);
            }

            // Restore to "hole" ')'
            s[offset + i] = ')';
        }
    }
    vector<string> m_res;
};

int main() {
    Solution so;
    vector<string> res = so.generateParenthesis(3);
    for (auto const &i : res) {
        cout << i << endl;
    }

    return 0;
}
