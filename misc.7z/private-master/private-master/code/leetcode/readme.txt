48 (2)
brute-force, just be careful about math..

CATION: uint arithmatic only produce uint(can be very large number if "negative"!!!  (1) int literal
type: (signed) int. e.g., 1 - 2 (2) compare: signed int will be converted to uint. e.g., int < uint?
+/-: signed int will be converted to uint. e.g., int +/- uint.  so: v.size() - 2 can produce a very
large number is v.size() = 0.2 can produce a very large number is v.size() = 0.  If a signed integer
overflows, the result is undefined. If an unsigned integer overflows, the result is defined modulo
2w, where w is the number of bits in that particular unsigned integer.
http://www.drdobbs.com/cpp/unsigned-arithmetic-useful-but-tricky/240001198

34 (1) (*)
recursion (not hard) non-recursion: 1st find low, 2nd find high (other's way). Try it! My
way: first find one match, then find low, find high, need 3 loops.

22 (1)
backtracking (worth trying!!!) Yet another much cleaner way by another user, based on binary
tree(worth trying!): https://discuss.leetcode.com/topic/36057/easy-java-solution/2


207 (3) (*)
DAG, topological sort, cyclic use adj matrix, but not as effectient as adj list.  (1)
THIS IS WRONG: if we meet a visited node, there is cyclic. (e.g., a->b, c->b) So visited alone is
not necessary (2) No need to find all roots. For both cases(topo sort, or cyclic detection), can
start DFS w/ any node. But just go through all unvisited nodes, if disconnected graph.  (3) Two
paradiams are useful(select one. 2nd?) A. ++preindex, dfs for children, ++postindex B. color = grey,
dfs for children, color = black  (default color is white) Think carefully. This problem actually has
nothing to do w/ topo sort. Just find cycle in a DAG.

210 (1) (*)
Similiar to 207. Use dependency graph + adj list(instead of matrix) is more efficient!

395 (3) (**) (worth trying!!!)
DP, use O(1) space to replace the init O(n^2) which is quadratic.
Great!  Don't use global variables. It will carry state among multiple test cases. Test will fail!

416 (2) (**) (worth trying!!!)
DP, but quite different from other DPs.  The brute-force way takes
O(2^n). To use DP, normal thinking is: for each subset combination(e.g.,s[1,3,8,11]), cache its sum
in a table. The problem is that we still need 2^n slots and time. We can think like this: we just
need to know "whether if the sum can be reached?", we don't need to know "which three or four
number's sum contributes to 10, e.g.,". So given this, one improvement is to use "all possible sum"
instead of "all possible combination of numbers" as to "index the table"! That brings us a linear
size table since both (1) # of array element (2) max value of each element, are limited.

Another way: is to use bitset<5001>. Very simple, but not necessarily faster, in the sense of
complexity.

417 (1) (*****) (worth trying) (more than half-day)
water flow in Atlantic/Pacific oceans.
DFS, but in a quite different way. The normal one-by-one DFS won't work as lots of node will have to
be re-updated. So instead of doing DFS for each matrix cell and trying to fixing/updating some
visited nodes with tricky methods, we can go the other way, start from edge cells and propogate
"change" backwards to all cells that can reach this cell!
Time: O(m*n). Think! Why? Because each cell has at most two change notifications before it's done.
(The same ocean notifition won't re-enter a node.)

410 (5) (*****) (worth trying) (NOT solved myself!)
using DP will cause either space/time excceed error. Try another way, use binary search!
very smart, yet tricky way to use binary search.

403 (2) (***) (worth trying)
dp with set.

