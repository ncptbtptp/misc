#include <iostream>
#include <vector>
#include <tuple>
using namespace std;

class Solution {
public:
   bool canFinish(int numCourses, vector<pair<int, int>>& pre) {
      buildAdjMatrix(numCourses, pre);

      // Special note: NO need to first find all roots in disconnected graph,
      // and start from these roots!!

      // Visit all unvisited nodes, for disconnected graph
      for (int i = 0; i < m_colors.size(); ++i) {
         if (!visited(i) && !dfs(i)) {
            return false;
         }
      }

      return true;
   }
private:
   enum tColor {
      tColor_white,
      tColor_grey,
      tColor_black
   };

   bool dfs(int node) {
      m_colors[node] = tColor_grey;
      for (int j = 0; j < m_matrix.size(); ++j) {
         if (m_matrix[node][j]) {
            // If the child is a grey node, we have a cycle!
            if (m_colors[j] == tColor_grey) {
               return false;
            }

            if (!visited(j) && !dfs(j)) {
               return false;
            }
         }
      }
      m_colors[node] = tColor_black;
      return true;
   }

   void buildAdjMatrix(int num, vector<pair<int, int>>& pre) {
      vector<bool> row(num, false);
      m_matrix.resize(num, row);
      // Not visited by default
      m_colors.resize(num, tColor_white);

      // Input (first depends on second), so draw second->first
      for (auto const &p : pre) {
         m_matrix[p.second][p.first] = true;
      }

      /* Find all roots, assuming disconnected graph */
      for (int j = 0; j < num; ++j) {
         bool found = false;
         for (int i = 0; i < num; ++i) {
            if (getLink(i, j)) {
               found = true;
               break;
            }
         }

         // in-degree of j is zero, root
         if (!found) {
            m_starts.push_back(j);
         }
      }
   }

   inline bool visited(int i) {
      return (m_colors[i] != tColor_white);
   }

   // Edge i->j
   inline void setLink(int i, int j) {
      m_matrix[i][j] = true;
   }

   // Is edge i->j ?
   inline bool getLink(int i, int j) {
      return m_matrix[i][j];
   }

   vector<vector<bool>> m_matrix;
   vector<tColor> m_colors;
   vector<int> m_starts;
};

int main()
{
   vector<pair<int, int>> v = {{1,0}, {2,6}, {1,7}, {5,1}, {6,4}, {7,0}, {0,5}, {5,1}, {6,4}};
   Solution so;
   cout << so.canFinish(8, v) << endl;

   return 0;
}
