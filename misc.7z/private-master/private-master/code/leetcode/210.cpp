#include <iostream>
#include <vector>
#include <tuple>
#include <cassert>
using namespace std;


class Solution {
public:
   vector<int> findOrder(int num, vector<pair<int, int>>& pre) {
      // Create adj list("dependency graph")
      m_adjList.resize(num);
      for (auto const &p : pre) {
         m_adjList[p.first].push_back(p.second);
      }
      m_colors.resize(num, tColor_white);
      
      for (int i = 0; i < num; ++i) {
         // We will NOT meet grey nodes here!
         assert(m_colors[i] != tColor_grey);

         if (!visited(i)) {
            if (!dfs_helper(i)) {
               return vector<int>();
            }
         }
      }

      return m_res;
   }

private:
   // Return false if cyclic
   bool dfs_helper(int node) {
      // Mark "entry"
      m_colors[node] = tColor_grey;

      for (int adj : m_adjList[node]) {
         // Cycle: caught on sight!
         if (m_colors[adj] == tColor_grey) {
            return false;
         }

         // The new child reports a cycle!
         if ((m_colors[adj] == tColor_white) && !dfs_helper(adj)) {
            return false;
         }
      }

      // "Dependency graph", so destination/child goes first
      m_res.push_back(node);
      
      // Mark "exit"
      m_colors[node] = tColor_black;
      return true;
   }

   inline bool visited(int node) {
      return (m_colors[node] != tColor_white);
   }


   enum tColor {
      tColor_white,
      tColor_grey,
      tColor_black
   };

   vector<tColor> m_colors;
   vector<int> m_res;
   vector<vector<int>> m_adjList;
};

int main()
{
   Solution so;
   vector<pair<int,int>> pre = {{1,0}, {2,0}, {3,1}, {0,1}};
   vector<int> res = so.findOrder(4, pre);

   for (int i : res) {
      cout << i << ", ";
   }
   cout << endl;

   return 0;
}
