#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

using namespace std;

class Solution {
public:
    /* This one is good, though too big time complexity(exponential)..
       Build set from length 1 to max length possible.

    vector<int> largestDivisibleSubset(vector<int>& nums)
    {
        sort(nums.begin(), nums.end());

        queue<vector<int>> s;

        for (int i = 0; i < nums.size(); ++i)
        {
            vector<int> t;
            t.push_back(i);
            s.push(t);
        }

        vector<int> last;
        while (!s.empty())
        {
            last = s.front();
            s.pop();  
            
            for (auto k : last)
                cout << k << "  ";
            cout << endl;


            int lastInt = nums[last.back()];
            for (int j = last.back() + 1; j < nums.size(); ++j)
            {
                if ((nums[j] % lastInt == 0) || (lastInt % nums[j] == 0))
                {
                    vector<int> t = last;
                    t.push_back(j);
                    s.push(t);
                }
            }
        }

        vector<int> res;
        for (auto i : last)
            res.push_back(nums[i]);

        return res;
    }
    */

    vector<int> largestDivisibleSubset(vector<int>& nums)
    {
        if ((nums.size() == 0) || (nums.size() == 1))
        {
            return nums;
        }

        // dp[i]: size of largest subset containing and ending at nums[i]
        // must be initialized to 1, not 0
        vector<int> dp(nums.size(), 1);

        // auxiliary array to help build the largest subset
        // pre[i]: index of previous number in the largest subset denoted by dp[i]
        vector<int> pre(nums.size(), -1);

        // necessary to simplify
        sort(nums.begin(), nums.end());


        for (int i = 1; i < nums.size(); ++i)
        {
            // don't use size_t as it never ends the loop..
            for (int j = i - 1; j >= 0; --j)
            {
                // optimization: no need to move on since the length
                // can't be bigger than dp[i] already
                if (dp[i] >= i + 2)
                {
                    break;
                }

                if ((nums[i] % nums[j] == 0) && (dp[j] + 1 > dp[i]))
                {
                    dp[i] = dp[j] + 1;
                    pre[i] = j;
                }

            }
        }

        // find last number of the largest subset
        int maxLength = -1, maxIdx = -1;
        for (int i = nums.size() - 1; i >= 0; --i)
        {
            if (dp[i] > maxLength)
            {
                maxLength = dp[i];
                maxIdx = i;
            }
        }

        // store the numbers in increasing order
        vector<int> maxSet(maxLength, -1);

        // and traverse back to get the whole set
        int i = maxIdx;
        vector<int>::reverse_iterator it = maxSet.rbegin();
        while (i != -1)
        {
            *it = nums[i];
            ++it;
            i = pre[i];
        }

        return maxSet;
    }
};

int main()
{
    int arr[] = {3, 4, 16, 8};
    vector<int> nums(arr, arr + sizeof(arr) / sizeof(arr[0]));

    Solution so;
    vector<int> res = so.largestDivisibleSubset(nums);
    for (auto i : res)
        cout << i << endl;

    return 0;
}
