#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

using namespace std;

class Solution {
public:
    double findMedianSortedArrays(vector<int>& nums1, vector<int>& nums2)
    {
        // trick so that findMedian() can always assume 1st array is smaller
        if (nums1.size() > nums2.size())
            return findMedian(nums2, 0, nums2.size() - 1, nums1, 0, nums1.size() - 1);
        else
            return findMedian(nums1, 0, nums1.size() - 1, nums2, 0, nums2.size() - 1);
    }

private:
    // assumes nums1[s1, t1] is no larger than nums2[s2, t2] in length
    double findMedian(vector<int>& nums1, int s1, int t1, vector<int>& nums2, int s2, int t2)
    {
        int n1 = t1 - s1 + 1, n2 = t2 - s2 + 1;

        // all base cases..

        // case 1: both arrays are empty
        if (n2 <= 0)
        {
            return -1;
        }

        // case 2: small array is empty
        // return median of big array
        if (n1 <= 0)
        {
            return median(nums2, 0, nums2.size() - 1);
        }

        // case 3: size of both arrays are 1
        if (n2 == 1)
        {
            // 2.0: force double
            return (nums1[s1] + nums2[s2]) / 2.0;
        }

        // case 4: size of small array is 1
        if (n1 == 1)
        {
            if (n2 % 2 != 0)
            {
                int m = median(nums2[(s2 + t2) / 2 - 1],
                               nums2[(s2 + t2) / 2 + 1],
                               nums1[s1]);
                return (m + nums2[(s2 + t2) / 2]) / 2.0;
            }
            else
            {
                return median(nums2[(s2 + t2) / 2],
                              nums2[(s2 + t2) / 2 + 1],
                              nums1[s1]);
            }
        }

        // case 5: size of both arrays are 2
        if (n2 == 2)
        {
            return (max(nums1[s1], nums2[s2]) + min(nums1[t1], nums2[t2])) / 2.0;
        }

        // case 6: size of small array is 2
        if (n1 == 2)
        {
            if (n2 % 2 != 0)
            {
                return median(nums2[(s2 + t2) / 2],
                              max(nums2[(s2 + t2) / 2 - 1], nums1[s1]),
                              min(nums2[(s2 + t2) / 2 + 1], nums1[t1]));
            }
            else
            {
                return median(nums2[(s2 + t2) / 2],
                              nums2[(s2 + t2) / 2 + 1],
                              max(nums1[s1], nums2[(s2 + t2) / 2 - 1]),
                              min(nums1[t1], nums2[(s2 + t2) / 2 + 2]));
            }
        }

        // here it's also different from two-arrays-of-equal-size problem, a trick
        // recursion
        int idx1 = (s1 + t1) / 2;
        int idx2 = (s2 + t2) / 2;

        // important: how to scale down (different than two-arrays-of-same-size problem)
        // make sure: same size is cut from two arrays(thus not necessarily half for big array)
        if (nums1[idx1] <= nums2[idx2])
            return findMedian(nums1, idx1, t1, nums2, s2, n2 - idx1 + s2 - 1);
        else
            return findMedian(nums1, s1, n1 - idx1 + s1 - 1, nums2, idx1, t2);
    }

    double median(int a, int b, int c, int d)
    {
        vector<int> t;
        t.push_back(a);
        t.push_back(b);
        t.push_back(c);
        t.push_back(d);
        sort(t.begin(), t.end());
        return median(t, 0, 3);
    }

    double median(int a, int b, int c)
    {
        if ((a >= b && b >= c) || (a <= b && b <= c)) return b;
        if ((a >= c && c >= b) || (a <= c && c <= b)) return c;
        return a;
    }

    // return median of a single non-empty sorted array
    double median(vector<int>& nums, int s, int t)
    {
        int n = t - s + 1;
        if (n % 2 == 0)
            return (nums[s + n/2 - 1] + nums[s + n/2]) / 2.0;
        else
            return nums[s + n/2];
    }
};
int main()
{
    int arr1[] = {1, 5, 6};
    int arr2[] = {2, 3, 4, 7, 8};

    vector<int> nums1(arr1, arr1 + sizeof(arr1) / sizeof(arr1[0]));
    vector<int> nums2(arr2, arr2 + sizeof(arr2) / sizeof(arr2[0]));

    Solution so;
    cout << so.findMedianSortedArrays(nums1, nums2) << endl;

    return 0;
}

