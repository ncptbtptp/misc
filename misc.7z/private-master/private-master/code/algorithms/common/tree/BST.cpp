#include <iostream>
#include <cassert>

using namespace std;

struct tNode {
    tNode (int v):
        value(v),
        left(nullptr),
        right(nullptr)
    {}
    int value;
    tNode *left;
    tNode *right;
};

void BST_display(tNode *root)
{
    if (root) {
        BST_display(root->left);
        cout << root->value << ", ";
        BST_display(root->right);
    }
}

tNode* BST_search(tNode *root, int key)
{
    if (!root) {
        return nullptr;
    }

    if (root->value == key) {
        return root;
    }
    else if (key < root->value) {
        return BST_search(root->left, key);
    }
    else {
        return BST_search(root->right, key);
    }
}

tNode* BST_insert_helper(tNode *node, tNode *parent, int key)
{
    if (!node) {
        tNode *n = new (nothrow) tNode(key);
        if (n && parent) {
            if (key < parent->value) parent->left = n;
            else parent->right = n;
        }
        return n;
    }
    else if (key < node->value) {
        return BST_insert_helper(node->left, node, key);
    }
    else {
        return BST_insert_helper(node->right, node, key);
    }
}

// Returns new node
tNode* BST_insert(tNode *root, int key)
{
    return BST_insert_helper(root, NULL, key);
}

// Return (parent, node_found)
std::pair<tNode*, tNode*> BST_inorderMin(tNode *root, tNode *parent) {
   if (!root) return make_pair(nullptr, nullptr);

   while (root->left) {
      parent = root;
      root = root->left;
   }

   return make_pair(parent, root);
}

// Return the root(can be new!)
void BST_remove_helper(tNode *root, tNode *parent, int key) {
   // ROOT or empty tree has already been handled
   assert (root && (root->value != key));

   // If we are deleting this node
   if (root->value == key) {
      if (!root->left) {
        if (root->value < parent->value) parent->left = root->right;
        else parent->right = root->right;
        delete root;
      }
      else if (!root->right) {
        if (root->value < parent->value) parent->left = root->left;
        else parent->right = root->left;
        delete root;
      }
      // Two children
      // Replace value instead of node
      else {
         // Easier than inorderNext(root)! when implementing
         // inorderNext
         pair<tNode*, tNode*> p = BST_inorderMin(root->right, root);
         root->value = (p.second)->value;
         BST_remove_helper(p.second, p.first, root->value);
      }
   }
   else if (key < root->value) {
      BST_remove_helper(root->left, root, key);
   }
   else {
      BST_remove_helper(root->right, root, key);
   }
}





int main()
{
    return 0;
}
