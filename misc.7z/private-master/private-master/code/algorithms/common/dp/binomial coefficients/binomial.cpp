/*
 * Problem: binomial coefficient C(n, k)
 * Source: <<Foundation of Algorithms>>
 * Time: O(n*k)
 * Cat: dynamic programming
*/

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int bin(int n, int k)
{
	vector<int> row(1 + k); // 0 ~ k
	vector<vector<int> > table;

	for (int i = 0; i <= n; ++i)
		table.push_back(row);

	for (int i = 0; i <= n; ++i)
	{
		for (int j = 0; j <= min(i, k); ++j)
		{
			// C(n, 0) = 1, and C(n, n) = 1
			if (j == 0 || i == j)
				table[i][j] = 1;
			else
				table[i][j] = table[i - 1][j] + table[i - 1][j - 1];

		}
	}
	
	return table[n][k];
}

// Optimized version with one array
int bin2(int n, int k)
{
	vector<int> table(k + 1); // 0 ~ k
	// Not "=n" since last row we just need C(n, k), i.e., table[k]
	for (int i = 0; i < n; ++i)
	{
		// Write from right to left
		for (int j = min(i, k); j >= 0; --j)
		{
			if (j == 0 || j == i)
				table[j] = 1;
			else
				table[j] = table[j] + table[j-1];
		}
	}
	// We only need C(n, k) for the last row(i == n)
	return table[k - 1] + table[k];
}

int main(int argc, char *argv[])
{
    if (argc != 3)
	{
		cout << "Usage: " << argv[0] << " n k\n";
		return 0;
	}

	int n = atoi(argv[1]), k = atoi(argv[2]);
	cout << "C(" << n << ", " << k << ") = " << bin(n, k) << endl;
	cout << "C(" << n << ", " << k << ") = " << bin2(n, k) << endl;
}

