#include <iostream>
#include <climits>
#include <iomanip>

using namespace std;

#define N 5

// Sample data taken from the book
// Careful!! If you pick UINT_MAX, it can easily overflow..:
// D[i][k - 1] + D[k - 1][j]
// So we use 10000 for now..
#define THRESHOLD 10000
const unsigned int W[N][N] = 
{
	0, 		    1,		    THRESHOLD,  1, 		    5,
	9, 		    0, 		    3,		    2, 		    THRESHOLD,
	THRESHOLD,  THRESHOLD,  0,		    4, 		    THRESHOLD,
	THRESHOLD,  THRESHOLD,  2,		    0, 		    3,
	3,		    THRESHOLD,  THRESHOLD,  THRESHOLD,  0
};

// Length of shortest path
unsigned int D[N][N];
// Detailed shortest path
unsigned int P[N][N];

void printShortestLength();

void calShortestPath()
{
    // Initialize D(0) with W
	for (size_t i = 0; i < N; ++i)
		for (size_t j = 0; j < N; ++j)
			D[i][j] = W[i][j];

	// Calculating D(1), .. , D(N)
	for (size_t k = 1; k <= N; ++k)
    {
		for (size_t i = 0; i < N; ++i)
	    {
			for (size_t j = 0; j < N; ++j)
			{
				D[i][j] = min(D[i][j], D[i][k - 1] + D[k - 1][j]);
			}
		}
	}
}

void printShortestLength()
{
	// Unfortunately, std::setw() and set::left only applies to the next item
	// so we have to apply them to every cout object
	for (size_t i = 0; i < N; ++i)
	{
		for (size_t j = 0; j < N; ++j)
			cout << std::setw(10) << std::left << D[i][j] << "     ";
		cout << endl;
	}
	cout << endl;
}

int main()
{
	calShortestPath();
	printShortestLength();

	return 0;
}
