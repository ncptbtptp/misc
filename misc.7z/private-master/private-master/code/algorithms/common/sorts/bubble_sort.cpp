#include <algorithm>

void bubble_sort(int data[], int n)
{
   for (int last = n - 1; last > 0; --last)
   {
      bool swapped = false;
      for (int i = 0; i < last; ++i)
      {
         if (data[i] > data[i + 1])
         {
            std::swap(data[i], data[i + 1]);
            swapped = true;
         }
      }
      if (!swapped) break;
   }
}
