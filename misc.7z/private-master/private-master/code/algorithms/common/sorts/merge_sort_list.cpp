#include <algorithm>
#include <iostream>
#include <cassert>

struct tListNode
{
   tListNode(int value = -1, tListNode *link = NULL): data(value), next(link)
   {}
   int data;
   tListNode *next;
};

tListNode *create_list(int a[], int n)
{
   try
   {
      tListNode sentinal, *cur = &sentinal;
      for (int i = 0; i < n; ++i)
      {
         cur->next = new tListNode(a[i]);
         cur = cur->next;
      }
      cur->next = NULL;
      return sentinal.next;
   }
   catch (const std::bad_alloc &)
   {
      return NULL;
   }
}

void destroy_list(tListNode *list)
{
   assert(list);

   tListNode *cur = NULL;
   while (list)
   {
      tListNode *cur = list;
      list = list->next;
      delete cur;
   }
}

void print_list(tListNode *list)
{
   assert(list);

   while (list)
   {
      std::cout << list->data << " ";
      list = list->next;
   }
   std::cout << std::endl;
}

// Returns the middle (the last node of the first sublist) of the list.
tListNode* get_middle(tListNode *list)
{
   assert(list);

   if (!list->next) return list;

   tListNode *slow = list, *fast = list->next;
   while (fast)
   {
      fast = fast->next;
      if (fast)
      {
         fast = fast->next;
         slow = slow->next;
      }
   }
   return slow;
}

// Merges two NULL terminated lists "in place" into a single NULL terminated list.
tListNode* merge(tListNode *first, tListNode *second)
{
   assert(first && second);

   tListNode sentinal, *cur = &sentinal;
   while (first && second)
   {
      if (first->data <= second->data)
      {
         cur->next = first;
         cur = first;
         first = first->next;
      }
      else
      {
         cur->next = second;
         cur = second;
         second = second->next;
      }
   }
   if (first) cur->next = first;
   if (second) cur->next = second;
   return sentinal.next;
}

// Merge sort a NULL terminated list.
tListNode* merge_sort(tListNode *list)
{
   assert(list);

   if (!list->next) return list;

   // mid is the last node of the first sublist
   tListNode *mid = get_middle(list);
   tListNode *second = mid->next;
   mid->next = NULL;
   list = merge_sort(list);
   second = merge_sort(second);
   return merge(list, second);
}
