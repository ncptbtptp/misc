#include <list>
#include <cassert>

using namespace std;

// Insert a[index] in a[0, index - 1] using binary search
void binary_insert(int a[], int index)
{
   assert ((index > 0) && (a[index] < a[index - 1]));
   int low = 0, high = index - 1;
   int temp = a[index];
   // Loop invariant: a[i] > temp if i >= high; a[i] <= temp if i < low.
   // a[mid] equal to temp is treated the same as if it were smaller, to ensure
   // this is still a stable sort.
   while (low != high)
   {
      int mid = (low + high) / 2;
      if (a[mid] > temp) high = mid;
      else low = mid + 1;
   }

   for (int i = index; i > high; --i) a[i] = a[i - 1];
   a[high] = temp;
}

//// Yet another stable version with a different invariant.
//void binary_insert(int a[], int index)
//{
//   assert ((index > 0) && (a[index] < a[index - 1]));
//   int low = 0, high = index - 1;
//   int temp = a[index];
//   // Loop invariant: a[i] > temp if i > high; a[i] <= temp if i < low.
//   while (low < high)
//   {
//      int mid = (low + high) / 2;
//      if (a[mid] > temp) high = mid - 1;
//      else low = mid + 1;
//   }
//
//   int insert_idx = -1;
//   if (low == high)
//   {
//      insert_idx = (a[high] <= temp) ? high + 1 : high;
//   }
//   else
//   {
//      assert (high + 1 == low);
//      insert_idx = low;
//   }
//
//   for (int i = index; i > insert_idx; --i) a[i] = a[i - 1];
//   a[insert_idx] = temp;
//}

// Straight insertion sort
void insertion_sort_straight(int a[], int n)
{
   for (int first_unsorted = 1; first_unsorted < n; ++first_unsorted)
   {
      if (a[first_unsorted] < a[first_unsorted - 1])
      {
         int temp = a[first_unsorted];
         int i = first_unsorted;
         // Loop invariant: i is the empty slot
         do {
            a[i] = a[i - 1];
            --i;
         }while ((i > 0) && (temp < a[i - 1]));
         a[i] = temp;
      }
   }
}

// Binary insertion sort
void insertion_sort_binary(int a[], int n)
{
   for (int first_unsorted = 1; first_unsorted < n; ++first_unsorted)
   {
      if (a[first_unsorted] < a[first_unsorted - 1])
      {
         binary_insert(a, first_unsorted);
      }
   }
}

// Sorts a linked list
void insertion_sort(list<int>& a)
{
   if (a.size() <= 1) return;

   typedef list<int>::iterator tListIt;
   typedef list<int>::reverse_iterator tListRIt;
   tListIt first_unsorted = a.begin();
   // The first element is trivially sorted.
   ++first_unsorted;

   while (first_unsorted != a.end())
   {
      tListIt nextIt = first_unsorted;
      ++nextIt;

      tListRIt rit(first_unsorted);
      while ((rit != a.rend()) && (*first_unsorted < *rit)) ++rit;
      a.splice(rit.base(), a, first_unsorted);

      first_unsorted = nextIt;
   }
}
