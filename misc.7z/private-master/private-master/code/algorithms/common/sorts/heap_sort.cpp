#include <algorithm>
#include <cassert>

inline int left_child(int i, int n)
{
   int child = i * 2 + 1;
   return (child < n) ? child : -1;
}

inline int right_child(int i, int n)
{
   int child = i * 2 + 2;
   return (child < n) ? child : -1;
}

inline bool is_leaf(int i, int n)
{
   return ((i >= (n / 2)) && (i < n));
}

// Pre: both child of a[i] are max heaps. a[i] may volatile max heap property.
// Post: subarray a[i, n - 1] is a max heap.
void max_heapify(int a[], int i, int n)
{
   assert(i < n);

   while (!is_leaf(i, n))
   {
      int left = left_child(i, n);
      int right = right_child(i, n);
      assert(left != -1);
      int max = ((right != -1) && (a[right] > a[left])) ? right : left;

      if (a[max] > a[i])
      {
         std::swap(a[i], a[max]);
         i = max;
      }
      else
      {
         break;
      }
   }
}

void build_heap(int a[], int n)
{
   // Build heaps backwards, from the last non-leaf node.
   for (int i = n / 2 - 1; i >= 0; --i)
   {
      max_heapify(a, i, n);
   }
}

void heap_sort(int a[], int n)
{
   build_heap(a, n);

   for (int last_heap_node = n - 1; last_heap_node > 0; --last_heap_node)
   {
      std::swap(a[0], a[last_heap_node]);
      max_heapify(a, 0, last_heap_node);
   }
}