#include <algorithm>
#include <list>

using namespace std;

// Sorts a C-style array
void selection_sort(int a[], int n)
{
   for (int first_unsorted = 0; first_unsorted < n - 1; ++first_unsorted)
   {
      int min_idx = first_unsorted;
      for (int i = first_unsorted + 1; i < n; ++i)
      {
         if (a[i] < a[min_idx]) min_idx = i;
      }
      if (min_idx != first_unsorted) swap(a[min_idx], a[first_unsorted]);
   }
}

// Sorts a linked list
void selection_sort(list<int>& a)
{
   if (a.empty()) return;

   typedef list<int>::iterator tListIt;

   tListIt end_it = a.end();
   --end_it;
   for (tListIt first_unsorted = a.begin(); first_unsorted != end_it;)
   {
      tListIt min_it = first_unsorted, it = first_unsorted;
      ++it;
      while (it != a.end())
      {
         if (*it < *min_it) min_it = it;
         ++it;
      }
      // Transfers/inserts "min_it" to the position of "first_unsorted".
      // Effectively, "first_unsorted" remains. "end()" may change though.
      if (min_it != first_unsorted) a.splice(first_unsorted, a, min_it);
      else ++first_unsorted;
      end_it = a.end();
      --end_it;
   }
}