#include <algorithm>
#include <cassert>

//// Just another version of merge().
//void merge(int a[], int left, int mid, int right, int b[])
//{
//   assert((left <= mid) && (mid <= right));
//
//   int i = left, j = mid + 1, k = left;
//   while ((i <= mid) && (j <= right))
//   {
//      if (a[i] <= a[j]) b[k++] = a[i++];
//      else b[k++] = a[j++];
//   }
//   while (i <= mid) b[k++] = a[i++];
//   while (j <= right) b[k++] = a[j++];
//}

// Merges a[left, mid], a[mid + 1, right] to b[left, right].
void merge(int a[], int left, int mid, int right, int b[])
{
   assert((left <= mid) && (mid <= right));

   int i = left, j = mid + 1;
   for (int k = left; k <= right; ++k)
   {
      b[k] = ((i <= mid) && ((j > right) || (a[i] <= a[j]))) ? a[i++] : a[j++];
   }
}

// Copies a[0, n - 1] to b[0, n - 1]
void copy_array(int a[], int n, int b[])
{
   for (int i = 0; i < n; ++i) b[i] = a[i];
}

bool bottom_up_merge_sort(int a[], int n)
{
   if ((n == 0) || (n == 1)) return true;

   int *b = new (std::nothrow) int [n];
   if (!b) return false;

   int *src = a, *dst = b;
   for (int len = 1; len < n; len *= 2)
   {
      // Splice subarrays of size "len" 
      for (int i = 0; i < n; i += 2 * len)
      {
         merge(src, i, std::min(i + len, n) - 1, std::min(i + 2 * len, n) - 1, dst);
      }
      std::swap(src, dst);
   }

   if (src != a) copy_array(src, n, a);

   delete [] b;
   return true;
}

// Pre: array "dst" and "src" contain the same contents (deep copy).
// Post: array "dst" contains the merged result.
void recursive_merge(int *src, int left, int right, int *dst)
{
   assert(src && dst);
   if (left >= right) return;

   const int split = (left + right) / 2;

   recursive_merge(dst, left, split, src);
   recursive_merge(dst, split + 1, right, src);
   merge(src, left, split, right, dst);
}

bool top_down_merge_sort(int a[], int n)
{
   int *b = new (std::nothrow) int [n];
   if (!b) return false;
   copy_array(a, n, b);

   recursive_merge(b, 0, n - 1, a);

   delete [] b;
   return true;
}
