// How to print a binary tree "literally"
// By "literally", we mean:
// (1) easy to find parent given child (2) easy to find children given parent
// 
// from:《程序员代码面试指南：“如何较为直观得打印二叉树”》

#include <iostream>
#include <string>

using namespace std;

struct tTreeNode
{
   tTreeNode(int d): data(d)
   {
      left = right = NULL;      
   }
   tTreeNode(int d, tTreeNode *l, tTreeNode *r): data(d), left(l), right(r)
   {}

   int data;
   tTreeNode *left;
   tTreeNode *right;
};

void printNode(tTreeNode *node, int indent)
{
   cout << node->data << endl;
   // An indent is a continuous span of whitespaces
   string space(indent, ' ');

   // Print left tree if any
   if (node->left)
   {
      // "<<<" means left child
      cout << space << " <<< ";
      printNode(node->left, indent + 5);
   }

   // Print right tree if any
   if (node->right)
   {
      // ">>>" means right child
      cout << space << " >>> ";
      printNode(node->right, indent + 5);
   }

}

void print(tTreeNode *root)
{
   if (!root) return;
   printNode(root, 0);
}

tTreeNode* createBTree()
{
   tTreeNode *n6 = new tTreeNode(6);
   tTreeNode *n4 = new tTreeNode(4);
   tTreeNode *n5 = new tTreeNode(5, NULL, n6);
   tTreeNode *n2 = new tTreeNode(2, n4, NULL);
   tTreeNode *n3 = new tTreeNode(3, n5, NULL);
   tTreeNode *n1 = new tTreeNode(1, n2, n3);
   return n1;
}

int main()
{
   tTreeNode *root = createBTree();
   print(root);

   return 0;
}
