// Check if string str1 is a sub-sequence of another string str2
// From: longest common sequence of two strings, complexity of brute force way
// Complexity: linear! O(n), n is length of str2.

#include <iostream>
#include <cstring> // for strlen()
using namespace std;

// Just another way from geeksforgeeks.org:
// http://www.geeksforgeeks.org/given-two-strings-find-first-string-subsequence-second/
bool findSeq(char *str1, char *str2)
{
    if (!str1)
        return true;
    if (!str2)
        return false;

    // (i, m) is the index and length of the str1
    int m = strlen(str1), n = strlen(str2);
    if (m > n)
        return false;

    int i = 0;
    for (j = 0; i < m && j < n; ++j)
    {
        if (str1[i] == str2[j])
            ++i;
    }

    return (i == m);
}

bool findSeq(char *str1, char *str2)
{
    if (!str1)
        return true;
    if (!str2)
        return false;
    if (strlen(str1) > strlen(str2))
        return false;
    
    int i = 0, j = 0;
    while (j < strlen(str2))
    {
        if (str2[j] == str1[i])
        {
            ++i;
            ++j;
        }
        else
        {
            ++j;
        }

        if (i >= strlen(str1))
            return true;
    }

    return false;
}

int main(int argc, char *argv[])
{
    if (argc != 3)
        cout << "Incorrect arguments! Try: exe str1 str2\n";
    cout << findSeq(argv[1], argv[2]) << endl;
    return 0;
}
