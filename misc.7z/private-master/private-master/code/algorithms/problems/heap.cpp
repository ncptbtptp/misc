#include <iostream>
using namespace std;

int left(int i)
{
   return 2*i + 1;
}

int right(int i)
{
    return 2*i + 2;
}

int parent(i)
{
    if (i != 0)
        return (i - 1) / 2;
    else
        return -1;
}

bool is_leaf(int i, int n)
{
    return (i >= n/2);
}

// n: length of heap
void sift_down(int a[], int n, int i)
{
    while (!is_leaf(i, n))
    {
        int k = i;
        if ((left(i) < n) && (a[left(i)] < a[k]))
            k = left(i);
        if ((right(i) < n) && (a[right(i)] < a[k]))
            k = right(i);
        if (k != i)
        {
            int temp = a[i];
            a[i] = a[k];
            a[k] = temp;
            i = k;
        }
        else
        {
            // sub-tree rooted at i is already a min-heap
            break;
        }
    }
}
