/*
 * Author: yingmu1983@gmail.com
 * Date: Sun Oct  2 16:50:53 CST 2016
 *
 * This example shows:
 * 1. How to define a variable of function pointer type.
 * 2. How to define a type of function pointer.
 * 3. How to define a C++ functor.
 * 4. Use w/ for_each().
 */

#include <iostream>
#include <typeinfo>  // To print variable type
#include <algorithm> // for_each()
#include <vector>
#include <tuple>     // Since c++11, so be sure to use -std=c++11

using namespace std;

int add(int a, int b)
{
    return a + b;
}

int multiply(int a, int b)
{
    return a * b;
}

void funcVariable()
{
    int a = 3, b = 4;

    // Define a variable of function pointer type, and initialize it w/ add().
    int (*funVar)(int, int) = add;


    cout << funVar(a, b) << endl;

    // Assign to another function
    funVar = multiply;
    cout << funVar(a, b) << endl;

    cout << "Type of funVar is: " << typeid(funVar).name() << endl;
}

void funcType()
{
    int a = 3, b = 4;

    // Define a function pointer type.
    typedef int (*tFunVar)(int, int);

    tFunVar ptr = add;
    cout << ptr(a, b) << endl;

    // Assign to another function
    ptr = multiply;
    cout << ptr(a, b) << endl;
}

class tOperation
{
    // This definition must appear before its first use,
    // unlike class member variables.
    typedef int (*tFunVar)(int, int);
public:
    tOperation(tFunVar func):
        _func(func)
    {}

    // Actually make this class a functor.
    // A functor can have arbitary number of parameters.
    int operator()(int op1, int op2) const
    {
        return _func(op1, op2);
    }

    // This overloaded version is used by for_each, called
    // for each element in a vector.
    void operator()(tuple<int, int> op) const
    {
        // Unpack operands
        cout << _func(get<0>(op), get<1>(op)) << endl;
    }
private:
    tFunVar _func;
};

void funcObject()
{
    tOperation sum(add);
    cout << sum(3, 4) << endl;

    tOperation multip(multiply);
    cout << multip(3, 4) << endl;
}

void funcObjectWithVector()
{
    vector<tuple<int, int>> v;
    for (size_t i = 0; i < 10; ++i)
    {
        v.push_back(make_tuple(i, i));
    }
    for_each(v.cbegin(), v.cend(), tOperation(add));
}

int main()
{
    //funcVariable();
    //funcType();
    //funcObject();
    funcObjectWithVector();

    return 0;
}
