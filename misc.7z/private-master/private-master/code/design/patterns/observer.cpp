#include "observer.h"
#include <iostream>
#include <algorithm> // for std::remove()
#include <assert.h>
using namespace std;

// Pure virtual dtor MUST provide a function body
CSubject::~CSubject()
{}

void CSubject::add_observer(CObserver *observer)
{
   m_observers.push_back(observer);
}

void CSubject::remove_observer(CObserver *observer)
{
   // std::remove is a logical removal
   m_observers.erase(std::remove(m_observers.begin(), m_observers.end(), observer), m_observers.end());
}

void CSubject::notify_observers()
{
   for (vector<CObserver *>::const_iterator it = m_observers.begin();
        it != m_observers.end(); ++it)
   {
      (*it)->update(this);
   }
}

void CWeatherData::set_measurements(float temperature, float pressure, float humidity)
{
   m_temperature = temperature;
   m_pressure = pressure;
   m_humidity = humidity;
   measurements_changed();
}

float CWeatherData::get_temperature() const
{
   return m_temperature;
}

float CWeatherData::get_pressure() const
{
   return m_pressure;
}

float CWeatherData::get_humidity() const
{
   return m_humidity;
}

void CWeatherData::measurements_changed()
{
   notify_observers();
}

CObserver::~CObserver()
{}

CApp::~CApp()
{}

CWebApp::CWebApp(CSubject *subject)
{
   subject->add_observer(this);
   m_subject = subject;
}

CWebApp::~CWebApp()
{
   m_subject->remove_observer(this);
}

void CWebApp::update(CSubject *subject)
{
   // If it's the subject we are listening, pull states we care.
   if (subject == m_subject)
   {
      cout << "CWebApp updated:" << endl;
      // cons of the pull model
      CWeatherData *data = dynamic_cast<CWeatherData*>(m_subject);
      assert(data);
      float temperature = data->get_temperature();
      float pressure = data->get_pressure();
      float humidity = data->get_humidity();
      display(temperature, pressure, humidity);
   }
}

void CWebApp::display(float temperature, float pressure, float humidity)
{
   cout << "CWebApp: " << temperature << ", " << pressure << ", " << humidity << endl; 
}

CEmailApp::CEmailApp(CSubject *subject)
{
   subject->add_observer(this);
   m_subject = subject;
}

CEmailApp::~CEmailApp()
{
   m_subject->remove_observer(this);
}

void CEmailApp::update(CSubject *subject)
{
   // If it's the subject we are listening, pull states we care.
   if (subject == m_subject)
   {
      cout << "CEmailApp updated:" << endl;
      CWeatherData *data = dynamic_cast<CWeatherData*>(m_subject);
      assert(data);
      float temperature = data->get_temperature();
      float pressure = data->get_pressure();
      float humidity = data->get_humidity();
      display(temperature, pressure, humidity);
   }
}

void CEmailApp::display(float temperature, float pressure, float humidity)
{
   cout << "CEmailApp: " << temperature << ", " << pressure << ", " << humidity << endl; 
}

int main()
{
   CWeatherData weatherData;
   CWebApp webApp(&weatherData);
   CEmailApp emailApp(&weatherData);
   weatherData.set_measurements(1.0, 2.0, 3.0);
   weatherData.set_measurements(4.0, 5.0, 6.0);

   return 0;
}
