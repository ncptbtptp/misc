#include <vector>

class CObserver;

class CSubject
{
public:
   void add_observer(CObserver *observer);
   void remove_observer(CObserver *observer);
   // virtual here because of possible polymorphic base class,
   // i.e., accessing derived class objects via base class pointers.
   // pure virtual: prevent direct instantiation.
   virtual ~CSubject() = 0;

protected:
   void notify_observers();

private:
   std::vector<CObserver *> m_observers;
};

class CWeatherData: public CSubject
{
public:
   void set_measurements(float temperature, float pressure, float humidity); 
   // Used by observers in a pull model
   float get_temperature() const; 
   float get_pressure() const;
   float get_humidity() const;

private:
   void measurements_changed();
   float m_temperature;
   float m_pressure;
   float m_humidity;
};

// Abstract class / interface
class CObserver
{
public:
   virtual ~CObserver() = 0;
   // If registers to multiple subjects, the param tells us which instance it is.
   // And we pull subject's states for things we are interested in.
   virtual void update(CSubject *subject) = 0; 
};

class CApp
{
public:
   virtual ~CApp() = 0;
   virtual void display(float temperature, float pressure, float humidity) = 0;
};

class CWebApp: public CObserver, public CApp
{
public:
   CWebApp(CSubject *subject);
   ~CWebApp();
   void update(CSubject *subject);
   void display(float temperature, float pressure, float humidity);

private:
   // This can't be moved to CObserver because we need add "this" observer to the subject. ??????
   CSubject *m_subject;
};

class CEmailApp: public CObserver, public CApp
{
public:
   CEmailApp(CSubject *subject);
   ~CEmailApp();
   void update(CSubject *subject);
   void display(float temperature, float pressure, float humidity);

private:
   CSubject *m_subject;
};
