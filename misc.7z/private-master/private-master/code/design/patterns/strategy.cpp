#include <iostream>
using namespace std;

class CWeapon
{
public:
   virtual void use_weapon() = 0;
};

class CKnife: public CWeapon
{
public:
   void use_weapon()
   {
      cout << "use knife" << endl;
   }
};

class CSword: public CWeapon
{
public:
   void use_weapon()
   {
      cout << "use sword" << endl;
   }
};

class CRifle: public CWeapon
{
public:
   void use_weapon()
   {
      cout << "use rifle" << endl;
   }
};

class CCharacter
{
public:
   CCharacter(CWeapon *weapon)
   {
      m_weapon = weapon;
   }

   void set_weapon(CWeapon *weapon)
   {
      m_weapon = weapon;
   }

   virtual void attack() = 0;

protected:
   CWeapon *m_weapon;
};

class CTerrorist: public CCharacter
{
public:
   CTerrorist(CWeapon *weapon): CCharacter(weapon)
   {}

   void attack()
   {
      cout << "Terrorists attack" << endl;
      m_weapon->use_weapon();
   }
};

class CCT: public CCharacter
{
public:
   CCT(CWeapon *weapon): CCharacter(weapon)
   {}

   void attack()
   {
      cout << "CTs fight" << endl;
      m_weapon->use_weapon();
   }
};

int main()
{
   CSword sword;
   CRifle rifle;
   CTerrorist terrorist(&sword);
   terrorist.attack();
   terrorist.set_weapon(&rifle);
   terrorist.attack();
   
   CCT ct(&sword);
   ct.attack();
   ct.set_weapon(&rifle);
   ct.attack();
   return 0;
}
