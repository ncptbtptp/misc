#include <pthread.h>
#include <iostream>

using namespace std;

pthread_once_t is_initialized = PTHREAD_ONCE_INIT;
int i = 0;

// void (*init_routine)(void); 
void library_initialize()
{
    /* Library initialization */    
    cout << "library_initialize() begin.\n";    
    ++i;
    cout << "library_initialize() end.\n";
}

void* library_func1(void *)
{
    cout << "library_func1().\n";
    pthread_once(&is_initialized, library_initialize);
    /* Operations performed after initialization */
    return 0;
}

void* library_func2(void *)
{
    cout << "library_func2().\n";
    pthread_once(&is_initialized, library_initialize);
    /* Operations performed after initialization */
    return 0;
}

int main()
{
    pthread_t f1, f2;
    pthread_create(&f1, NULL, library_func1, NULL);
    pthread_create(&f2, NULL, library_func2, NULL);
    pthread_join(f1, NULL);
    pthread_join(f2, NULL);
    cout << i << endl;
    return 0;
}
