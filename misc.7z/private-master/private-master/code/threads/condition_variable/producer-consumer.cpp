#include <iostream>
#include <cassert>
#include <pthread.h>
using namespace std;

// Implements classic producer-consumer (bounded buffer) problem
// TODO: error checking

// Total number of data to produce/consume
const unsigned int kNumOfData = 50;
// Shared circular buffer
const unsigned int kBufferCapacity = 10;
int g_buffer[kBufferCapacity];
// [g_tail, g_head) are to be consumed;
// [g_head, g_tail) are to be produced
int g_head = 0;
int g_tail = 0;

pthread_mutex_t g_mutex = PTHREAD_MUTEX_INITIALIZER;
// We need two CVs here. Otherwise, one consumer may wakeup another consumer,
// causing all producers/consumers deadlock.
// producer waits on g_slot_available, signals g_data_available;
// consumer waits on g_data_available, signals g_slot_available.
pthread_cond_t g_slot_available = PTHREAD_COND_INITIALIZER;
pthread_cond_t g_data_available = PTHREAD_COND_INITIALIZER;

bool is_buffer_full()
{
    // "1" is here to distinguish between "full" and "empty" state
    return ((g_head + 1) % kBufferCapacity == g_tail);
}

bool is_buffer_empty()
{
    return (g_head == g_tail);
}

void write(int data)
{
    assert(!is_buffer_full());
    g_buffer[g_head] = data;
    cout << "write " << data << " to slot " << g_head << endl;
    g_head = (g_head + 1) % kBufferCapacity;
}

void read()
{
    assert(!is_buffer_empty());
    cout << "read " << g_buffer[g_tail] << " from slot " << g_tail << endl;
    g_tail = (g_tail + 1) % kBufferCapacity;
}

void * producer(void *)
{
    for (int i = 0; i < kNumOfData; ++i)
    {
        pthread_mutex_lock(&g_mutex);
        while (is_buffer_full())
        {
            pthread_cond_wait(&g_slot_available, &g_mutex);
        }

        bool pre_empty = is_buffer_empty();
        write(i);

        // If the buffer is previously empty, wake any consumer.
        if (pre_empty)
        {
            pthread_cond_signal(&g_data_available);
        }
        pthread_mutex_unlock(&g_mutex);
        // Fairness
        pthread_yield();
    }
    return NULL;
}

void * consumer(void *)
{
    for (int i = 0; i < kNumOfData; ++i)
    {
        pthread_mutex_lock(&g_mutex);
        // Can't use "if". There could be multiple consumers,
        // and spurious wakeup, etc.
        while (is_buffer_empty())
        {
            pthread_cond_wait(&g_data_available, &g_mutex);
        }

        bool pre_full = is_buffer_full();
        read();

        // If the buffer is previously full, wake any producer.
        if (pre_full)
        {
            pthread_cond_signal(&g_slot_available);
        }
        pthread_mutex_unlock(&g_mutex);
        // Fairness
        pthread_yield();
    }
    return NULL;
}

int main()
{
    pthread_t p, c;
    pthread_create(&p, NULL, producer, NULL);
    pthread_create(&c, NULL, consumer, NULL);
    pthread_join(p, NULL);
    pthread_join(c, NULL);
    return 0;
}
