1. If base class method is overridden in derived class, the method actually called by a ref/pointer
to base class can either:
(1) early bound to ref/pointer type at compile time (not virtual; normal function overridding with
the same name)
(2) late binding (virtual)

2. Note that even if the virtual function is not called explicitly via base ref/pointer, but called
in base class normal member function, its resolution is still "late". This is because the implicit
"base" pointer in base.

E.g.,

class base
{
public:
   void normal()
   {
      func();
   }

   virtual void func()
   {
      cout << "func() in base\n";
   }
};

class derived: public base
{
public:
   // automatically virtual
   void func()
   {
      cout << "func() in derived\n";
   }
};

void main()
{
    base *pb = new derived;
    // derived::func() is called
    pb->normal();
}

3. Benefit: by using base ref/pointers, we don't/shouldn't care (1) what's the derived type (2) how
many derived types (3) how derived types implement virtual functions(details)

4. Pure virtual functions "typically" don't have a definition/implementation. But C++ allows to
provide a definition for pure virtual function. It can be used as a callback or "default
implementation" that derived overridden version can delegate to. Especially: pure virtual dtor.

5. Base class w/ ONLY pure virtual functions can be used as an interface. It works in C++ because
C++ supports multiple inheritance (thus multiple interfaces can be used).

6. Don't call virtual functions in ctor/dtor.
(1) In base class ctor, calling virtual functions will always resolve to base class version only.
(2) When constructing a derived class object, the base class part is constructed first, before the
derived part is constructed. Before the derived ctor is entered, the C++ language treats the object
as the type of base class (e.g., RTTI, dynamic_cast).
(3) This makes sense, since the derived ctor hasn't been called and data members in derived class
haven't been initialized yet. If virtual dispatching were allowed in base ctor, the derived version
will almost certainly access the uninitialized data in derived class. So C++ simply disables it.
(4) Same to dtor, since the derived part has been destructed already.

E.g.,
// template pattern
// But shouldn't use in base ctor!
class base
{
public:
   base()
   {
      // base version is called
      func();
   }

   virtual void func()
   {
      cout << "func() in base\n";
   }
};

class derived: public base
{
public:
   void func()
   {
      cout << "func() in derived\n";
   }
};

One way to approach:
Instead of passing customization down to derived classes via virtual function, pass info from
derived ctor to base ctor via parameters. So that the "customization" is now done in base ctor.

Note: since base class ctor is invoked in derived ctor's init list, all data members in derived
class haven't been initialized yet, we must use a "static helper function" to pass info to derived
ctor, to avoid using any uninitialized data. After all, that's the reason why "virtual dispatching"
is disabled in base ctor in the first place!


