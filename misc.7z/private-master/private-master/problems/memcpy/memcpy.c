/* memcpy
Basic questions:
1. What's the value of x = -x if x is unsigned long?
   
(two's complement of a negative stored in unsigned long with same underlying binary bits)
Effectively: binary bits of final x = ~x(bitwise NOT) + 1(add trailing 1)

2. Why not use size_t to represent WORD size?

WORD size: the width of registers, and pointer types, and most often, memory bus width as well.
In C/C++, long (or here unsigned long) is used to represent a WORD.
However, size_t is to present a size, which can be larger or smaller than a WORD. So it's not
appropriate to use it as the WORD type.

memcpy:
remember signature:
void* memcpy(void *dest, const void *src, size_t num);

1. What's the function signature? Why (void*)?
Probably not need for casting at caller side?
And it'a pure buffer no matter what it actually represents(bytes, structs, strings, etc)

2. What if when src and dst are overlapping
Depending on the beginning or end of dest overlaps w/ src, we need copy backward or forward

3. Performance?
Copy WORD-by-WORD from the first aligned address of dest. For unaligned address at the beginning and
end of dest, we have to copy byte-by-byte. This is use the alignment of dest. For src, also checks
if it's aligned or not if copy WORD-by-WORD.

4. Alignment issue?
See above.

5. threshold
If only a few bytes, uses copy-by-bytes directly

6. Copy by page?
On some systems, copying by pages can just map dest virtual pages to the same physical pages that
src virtual pages are mapped. So no actually copying are performed. No surprise copy-on-write is
used. No sure Linux supports it. GCC implementation will perform it if target platform supports it.

gcc implementation:
https://fossies.org/dox/glibc-2.24/string_2memcpy_8c_source.html

TODO:
1. gcc copy_by_word_fwd() is not directly copy word-by-word. Why?
2. copy like memmove() if overlaps

 */
#include <stdio.h>
#include <memory.h>

typedef unsigned char tByte;
typedef unsigned long tWord;
const size_t kWordSize = sizeof(tWord);

void copy_by_byte_fwd(tWord dest, tWord src, size_t size)
{
    for (size_t i = 0; i < size; ++i) {
        ((tByte*)dest)[i] = ((tByte*)src)[i];
    }
}

// Both @src and @dest are word-aligned
void copy_by_word_aligned_fwd(tWord dest, tWord src, size_t word_num)
{
    for (size_t i = 0; i < word_num; ++i) {
        ((tWord*)dest)[i] = ((tWord*)src)[i];
    }
}

// Only @dest is word-aligned
void copy_by_word_dest_aligned_fwd(tWord dest, tWord src, size_t word_num)
{
    for (size_t i = 0; i < word_num; ++i) {
        tWord cur = 0;
        // This is great! We can reuse copy_by_byte_fwd!
        copy_by_byte_fwd((tWord)&cur, src, kWordSize);
        ((tWord*)dest)[i] = cur;
        src += kWordSize;
    }
}

// dest must already be word-aligned
void copy_by_word_fwd(tWord dest, tWord src, size_t word_num)
{
    // src is also word-aligned
    if (src % kWordSize == 0) {
        copy_by_word_aligned_fwd(dest, src, word_num);
    }
    else {
        copy_by_word_dest_aligned_fwd(dest, src, word_num);
    }
}

void *my_memcpy(void *dest, const void *src, size_t byte_num)
{
    tWord destp = (tWord)dest;
    tWord srcp = (tWord)src;

    size_t num1 = (-destp) % kWordSize;
    size_t num3 = (byte_num - num1) % kWordSize;
    size_t num2 = byte_num - num1 - num3;

    copy_by_byte_fwd(destp, srcp, num1);
    copy_by_word_fwd(destp + num1, srcp + num1, num2 / kWordSize);
    copy_by_byte_fwd(destp + num1 + num2, srcp + num1 + num2, num3);

    return (void*)dest;
}

int main()
{
    char src[] = "hello, world, this is src";
    char dest[100];
    printf ("%lx\n", (tWord)src+1);
    printf ("%lx\n", (tWord)dest+1);
    my_memcpy(dest+1, src+1, sizeof(src));

    if (memcmp(dest+1, src+1, sizeof(src)) != 0) {
        printf ("Error!!\n");
    }

    printf ("%s\n", dest+1);

    return 0;
}


