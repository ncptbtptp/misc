1. Try not using cos(), sin(), sqrt(). And use as less * as possible.
2. Need integer numbers only.
3. A perfect circle can only be "simulated" by integer coordinates on the grid. Try to find closest.
4. It's not evenly distributed in 0~90 degree if you increase x. In 0-45, x increases faster. In 45-90,
y increases faster.
5. Can divide a circle into 8 parts, and just find closest points in 0-45 degrees and map to other 7.
6. One note: if point is on x or y axis, there is only other 3 points to map. But it's probably OK to
map 7 because two points are plotted at the same coordinates, which is fine.
7. When x increases by 1 in 0~45 degree, y can maintain the same or decrease by one. This must be
true because in 0~45 degree, x changed faster than y. (distorted)
