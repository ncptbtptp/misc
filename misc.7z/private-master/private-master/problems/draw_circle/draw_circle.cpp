/* Note: Using this application in console/terminal or text files won't generate a "circle", because
 *       of the inequal "gap" between rows and columns (mostly gap of rows > gaps of columns).
 *       You can write direct pixel using MFC dc->SetPixel() for example.
 *
 */
#include <iostream>
#include <vector>
#include <map>
#include <cmath>
#include <algorithm>
using namespace std;

void print_matrix(map<int, vector<int>> & matrix)
{
    for (auto &it : matrix) {
        // Sort the row so that we can print from left to right
        std::sort(it.second.begin(), it.second.end());

        int max_x = it.second.back();
        vector<bool> row(max_x + 1, false);

        for (auto x : it.second) {
            row[x] = true;
        }

        for (auto x : row) {
            if (!x) {
                cout << "  ";
            }
            else {
                cout << " *";
            }
        }
        // Change to the next row
        cout << endl;
    }
}

// Note that when (x, y) is on x-axis or y-axis, it will generate two equal overlapped points.
// So for ease, we can use a set instead of a vector
void plot(int x0, int y0, int x, int y, map<int, vector<int>> & matrix)
{
    //vector<pair<int, int>> points = { {x, y},
    //                                  {y, x},
    //                                  {y, -x},
    //                                  {x, -y},
    //                                  {-x, -y},
    //                                  {-y, -x},
    //                                  {-y, x},
    //                                  {-x, y} };
    vector<pair<int, int>> points = { {x, y},
                                      {y, x},
                                      {x, -y},
                                      {-y, x} };

    if (x != 0) {
        points.push_back(make_pair(y, -x));
        points.push_back(make_pair(-x, -y));
        points.push_back(make_pair(-y, -x));
        points.push_back(make_pair(-x, y));
    }

    for (auto p : points) {
        matrix[y0 + p.second].push_back(x0 + p.first);
    }
}

void draw_circle(int x0, int y0, int radius)
{
    map<int, vector<int>> matrix;

    int x = 0, y = radius;
    int error = 0;
    // Actually can be "x<y" because if x==y, then x,y must be a real number (from 2x^2 = r^2)
    // Which also means x!=y if x, y are integers!
    while (x <= y) {
        plot(x0, y0, x, y, matrix);
        int e1 = error + 2 * x + 1;
        int e2 = error + 2 * (x - y + 1);
        if (abs(e1) <= abs(e2)) {
            error = e1;
        }
        else {
            error = e2;
            --y;
        }
        ++x;
    }

    print_matrix(matrix);
}

int main()
{
    draw_circle(40, 0, 6);

    // Below: shows you even if you draw a square, you'll get a rectangle!
    //for (size_t i = 0; i < 10; ++i) {
    //    cout << "*";
    //}
    //cout << endl;
    //for (size_t i = 1; i <= 8; ++i) {
    //    cout << "*        *" << endl;
    //}
    //for (size_t i = 0; i < 10; ++i) {
    //    cout << "*";
    //}
    //cout << endl;
    return 0;
}
