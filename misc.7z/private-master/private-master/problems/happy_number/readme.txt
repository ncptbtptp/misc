1. If integer(i32), max 10 decimal digits. So sum of squares of its digits must be < 810.
2. Since there is a limited number of the square sum(810), this is a finite state machine. It takes
at most 810 steps (pretty loose upper bound;) for the loops to complete.
3. And actually the square sum will decrease! (see prove below)
[Attention: ONLY apply to decimal numbers those length >= 3. Easy prove that it's not correct for
2.]


Prove:

Let's just assume init number is (a1a2a3), without losing generality. 1<=a1<=9, 0<=a2<=9, 0<=a3<=9.

The number is: A = a1 * 100 + a2 * 10 + a3, the result sum is: B = a1 * a1 + a2 * a2 + a3 * a3.
We hope to prove that: A > B, so:

A - b = a1(100 - a1) + a2(10 - a2) + a3 (1 - a3)

The last item can be negative, and it has the min value when a3 is 9, so a3(1-a3) = -72
Can a1(100 - a1) always > 72 ? Let's see.

f(x) = x(100 - x) = -x^2 + 100x = -[(x-50)^2 - 2500]

Now draw the curve/graph related to this function:
         *
       *   *
     *       *
    *         *
   *           *
  *             *
 *               *
It opens downwards, and meets x-axis on (0, 0), and (100, 0), top is (50, 2500). Since a1 is within
[1, 9], so the min value is positive f(1) which is 1*99 = 99. This already compromises the negative
value of -72.

So it's guaranteed that the sequence of result number is decreasing (until it reaches two-digits
when it could 2->3->2->3->..  bouncing between two-digit numbers and three-digit numbers).

Solution #1
Use hash table to check if any number has been visited

Solution #2
Heuristic: for happy number, it will reach 1 in the end; for non-happy number, reach 4 in the end.

Solution #3
Floyd's cycle detection algorithm, w/o using hash table!

Followups:
1. Is the # of happy numbers finite? What about unhappy?
No. Since 1 is happy, 10^n are all happy.
No. Since 2 is unhappy, 2*10^n are all unhappy. (must encouter 4 in the loop for unhappy numbers)
