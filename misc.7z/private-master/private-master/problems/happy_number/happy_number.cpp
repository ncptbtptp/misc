#include <iostream>
#include <set>
#include <unordered_set>

using namespace std;

class Solution
{
public:
    // Solution #1: use math property: either reach 1 (happy number) or 4 (sad number) finally
    // Solution #2: use hash table
    // bool isHappy(int n)
    // {
    //     while (true) {
    //         if (n == 1) {
    //             return true;
    //         }
    //         else if (n == 4) {
    //             return false;
    //         }
    //         else {
    //             n = next(n);
    //         }
    //     }
    // }

    // Solution #3: Floyd cycle detection
    // O(1) space w/ hash table
    // Please note: how to prove correctness
    // 1. When slow reaches "entry point" of the cycle, fast must already be somwhere in cycle
    //    Since fast is 1 step faster, they will meet after DISTNACE iterations.
    // 2. Since next(1) is always 1, so if either is 1 after they meet, it's a happy number.
    //    Otherwise, it's not.
    bool isHappy(int n)
    {
        int slow = n, fast = n;
        do {
            slow = next(slow);
            fast = next(next(fast));
        }
        while (slow != fast);

        return (slow == 1);
    }

    /*
    bool isHappy(int n)
    {
        int slow = n, fast = next(n);
        while (true) {
            if (slow == 1 || fast == 1) {
                return true;
            }
            if (slow == fast) {
                return false;
            }
            slow = next(slow);
            fast = next(next(fast));
        }
    }
    */
private:
    int next(int n)
    {
        int res = 0;
        while (n) {
            res += square[n % 10];
            n /= 10;
        }
        return res;
    }

    int square[10] = {0, 1, 4, 9, 16, 25, 36, 49, 64, 81};

};

/*
// A very naive version
int lookup[] = {0, 1, 4, 9, 16, 25, 36, 49, 64, 81};
int square_sum(int n) {
    int sum = 0;
    while (n > 0) {
        int reminder = n % 10;
        sum += lookup[reminder];
        n = n / 10;
    }
    return sum;
}

bool isHappy(int n) {
    unordered_set<int> visited;

    while (true) {
        if (n == 1) return true;
        if (visited.find(n) != visited.end()) return false;
        visited.insert(n);
        n = square_sum(n);
    }
}
*/


int main()
{
    int n = 1;
    cout << Solution().isHappy(n) << endl;
    cout << isHappy(n) << endl;
    return 0;
}
