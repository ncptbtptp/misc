/* Design a O(1) map which meets the following requirements
 * O(1): add, remove, search, clear
 * O(# of existing items): iterate
 *
 * Related question: what and why is STL remove-erase idiom.
 * https://en.wikipedia.org/wiki/Erase-remove_idiom
 */

#include <unordered_map>
#include <iostream>
#include <vector>
#include <algorithm>   // std::swap, std::for_each

using namespace std;

class O1Map
{
public:
    void add(int key)
    {
        auto res = m_hash.find(key);
        // Already exists!
        if (res != m_hash.end()) {
            return;
        }

        // Important that hash bucket points to index, and array element points to key.
        // "double reference"
        m_array.push_back(key);
        m_hash[key] = m_array.size() - 1;
    }

    bool find(int key)
    {
        auto res = m_hash.find(key);
        return ((res != m_hash.end())     &&
            (res->second < m_array.size()) &&
            (key == m_array[res->second]));
    }

    void remove(int key)
    {
        if (!find(key)) {
            return;
        }

        auto res = m_hash.find(key);
        auto rm_idx = res->second;
        // If not last item, swap item-to-remove w/ the last item, to be O(1)
        if (rm_idx != m_array.size() - 1) {
            std::swap(m_array[rm_idx], m_array.back()); // back() does return a reference!
            m_hash[m_array[rm_idx]] = rm_idx;
        }

        // One alternative way to remove the last element from vector is:
        // "m_array.erase(std::move(m_array.begin(), m_array.end(), key), m_array.end())"
        // But that is NOT O(1).
        m_array.resize(m_array.size() - 1);   // or: m_array.erase(m_array.end() - 1);
        m_hash.erase(key);
    }

    // O(1) for POD
    // Otherwise, cannot use std::vector because of non-POD destructor
    void clear()
    {
        m_array.clear();
    }

    void iterate()
    {
        for_each(m_array.begin(), m_array.end(), [](int i) { cout << i << endl; });
    }

private:
    unordered_map<int, int> m_hash;

    // Two reasons we store keys in array:
    // 1. Helps check if hash entry is obsolete (we don't remove hash during O(1) clear())
    // 2. Required by O(# element count) iterate
    vector<int> m_array;
};

int main()
{
    O1Map m;
    return 0;
}
