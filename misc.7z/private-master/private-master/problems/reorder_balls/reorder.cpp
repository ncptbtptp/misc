#include <vector>
#include <queue>
#include <iostream>
#include <algorithm>
#include <ctime>
#include <cstdlib>
using namespace std;

/* 
 * Problem: Dutch flag problem
 * 1. Normal three-pointer solution
 * 2. Require min swaps
 * 3. Cal min swap number (return an int)
 */

 void random_vector(vector<int> &v)
 {
    int size = rand() % 1000 + 1;
    v.resize(size, 0);
    for (size_t i = 0; i < size; ++i) {
        // Generate number in [1, 2, 3]
        v[i] = rand() % 3 + 1;
    }
 }

// Another version, as the "golden standard", "criterion"
// Refer to:
// www.dewen.net.cn/q/7967
size_t min_swap_number_other(const vector<int> &v)
{
    vector<int> sorted = v;
    sort(sorted.begin(), sorted.end());
    int a1 = 0, a2 = 0, a3 = 0;
    for (size_t i = 0; i < v.size(); ++i)
    {
        if (sorted[i] == 1) {
            if (v[i] == 2) ++a1;
            else if (v[i] == 3) ++a3;
        }
        else if (sorted[i] == 2) {
            if (v[i] == 1) ++a2;
            else if (v[i] == 3) ++a3;
        }
    }
    return a3 + (a1 > a2 ? a1 : a2);
}

// c(a,b): b placed in area a
size_t min_swap_number(const vector<int> &v)
{
    vector<int> sorted = v;
    sort(sorted.begin(), sorted.end());
    int c21 = 0, c12 = 0, c31 = 0, c13 = 0, c23 = 0, c32 = 0;
    for (size_t i = 0; i < v.size(); ++i)
    {
        if (sorted[i] == 1) {
            if (v[i] == 2) ++c12;
            else if (v[i] == 3) ++c13;
        }
        else if (sorted[i] == 2) {
            if (v[i] == 1) ++c21;
            else if (v[i] == 3) ++c23;
        }
        else {
            if (v[i] == 1) ++c31;
            else if (v[i] == 2) ++c32;
        }
    }

    return min(c21, c12) + min(c31, c13) + min(c23, c32) + 2 * abs(c21 - c12);
}

static size_t s_actual_swaps = 0;

void swap(int &a, int &b)
{
    ++s_actual_swaps;
    std::swap(a, b);
}

void print(const vector<int> &v)
{
    for_each(v.begin(), v.end(), [](int i) { cout << i << " "; });
    cout << endl;
}

void partition_classic(vector<int> &a)
{
    int next1 = 0, next2 = 0, next3 = a.size() - 1;
    while (next2 <= next3) {
        if (a[next2] == 2) {
            ++next2;
        }
        else if (a[next2] == 1) {
            swap(a[next1++], a[next2++]);
        }
        else {
            swap(a[next2], a[next3--]);
        }
    }
}

// Assume balls are represented as 1, 2, 3
void partition(vector<int> &v)
{
    size_t cnt1 = 0, cnt2 = 0, cnt3 = 0;
    for (auto i : v) {
        if (i == 1) ++cnt1;
        else if (i == 2) ++cnt2;
        else ++cnt3;
    }

    size_t next1 = 0, next2 = cnt1, next3 = cnt1 + cnt2;
    // Last three bits: group#1, group#2, group#3
    int done_bit = 0; // b00000111

    // Previous bug: we cannot use (1+2+3) and minus, because it can be minus-ed multiple
    // times the while(true) loop and also will be negative.

    while (true) {
        // Make sure these bits are OK if operated multiple times.
        // Not ture for operator-
        while ((next1 < cnt1) && (v[next1] == 1)) ++next1;
        if (next1 == cnt1) done_bit |= 0x4;

        while ((next2 < cnt1 + cnt2) && (v[next2] == 2)) ++next2;
        if (next2 == cnt1 + cnt2) done_bit |= 0x2;

        while ((next3 < v.size()) && (v[next3] == 3)) ++next3;
        if (next3 == v.size()) done_bit |= 0x1;

        /* All groups are finished */
        if (done_bit == 0x7) {
            break;
        }

        /* Exactly two groups are not finished */
        // [1, 2]
        if (done_bit == 0x6) {
            swap (v[next1++], v[next2++]);
        }
        // [1, 3]
        else if (done_bit == 0x5) {
            swap (v[next1++], v[next3++]);
        }
        // [2, 3]
        else if (done_bit == 0x3) {
            swap (v[next2++], v[next3++]);
        }

        /* Exactly three groups are not finished
         * assert (done_bit == 0);
         */
        else if (v[next1] == 2 && v[next2] == 1) {
            swap (v[next1++], v[next2++]);
        }
        else if (v[next1] == 3 && v[next3] == 1) {
            swap (v[next1++], v[next3++]);
        }
        else if (v[next2] == 3 && v[next3] == 2) {
            swap (v[next2++], v[next3++]);
        }

        // [2, 3, 1]
        else if (v[next1] == 2 && v[next2] == 3) {
            swap(v[next1], v[next2++]);
            swap(v[next1++], v[next3++]);
        }
        // [3, 1, 2]
        else {
            swap(v[next1++], v[next2]);
            swap(v[next2++], v[next3++]);
        }
    }
}

// Min swaps with O(n) space
void partition_min_swaps(vector<int> &v)
{
    // Removing the 1st element from a vector is NOT O(1).
    // So we use queue here.
    queue<int> v2in1, v3in1, v1in2, v3in2, v1in3, v2in3;
    size_t size1 = 0, size2 = 0, size3 = 0;

    for (size_t i = 0; i < v.size(); ++i) {
        if (v[i] == 1) ++size1;
        else if (v[i] == 2) ++size2;
    }
    size3 = v.size() - size1 - size2;

    for (size_t i = 0; i < size1; ++i) {
        if (v[i] == 2) {
            v2in1.push(i);
        }
        else if (v[i] == 3) {
            v3in1.push(i);
        }
    }

    for (size_t i = size1; i < size1 + size2; ++i) {
        if (v[i] == 1) {
            v1in2.push(i);
        }
        else if (v[i] == 3) {
            v3in2.push(i);
        }
    }

    for (size_t i = size1 + size2; i < v.size(); ++i) {
        if (v[i] == 1) {
            v1in3.push(i);
        }
        else if (v[i] == 2) {
            v2in3.push(i);
        }
    }

    while (!v2in1.empty() && !v1in2.empty()) {
        swap(v[v2in1.front()], v[v1in2.front()]);
        v2in1.pop();
        v1in2.pop();
    }

    while (!v3in1.empty() && !v1in3.empty()) {
        swap(v[v3in1.front()], v[v1in3.front()]);
        v3in1.pop();
        v1in3.pop();
    }

    while (!v3in2.empty() && !v2in3.empty()) {
        swap(v[v3in2.front()], v[v2in3.front()]);
        v3in2.pop();
        v2in3.pop();
    }

    // Need swaps between three groups (effectively two swaps each)
    // Only one of the following two loops should run actually!
    while (!v2in1.empty()) {
        swap(v[v2in1.front()], v[v3in2.front()]);
        swap(v[v2in1.front()], v[v1in3.front()]);
        v2in1.pop();
        v3in2.pop();
        v1in3.pop();
    }

    while (!v3in1.empty()) {
        swap(v[v3in1.front()], v[v1in2.front()]);
        swap(v[v2in3.front()], v[v1in2.front()]);
        v3in1.pop();
        v1in2.pop();
        v2in3.pop();
    }
}


int main()
{
    vector<int> v;

    // Initialize the seed
    srand(time(NULL));
    while (true) {
        random_vector(v);

        size_t min_expected = min_swap_number(v);
        if (min_expected != min_swap_number_other(v)) {
            printf("ERROR! Minial swaps calculation is wrong!!\n");
            break;
        }

        vector<int> dup1(v), dup2(v), dup3(v);

        // Method #1
        s_actual_swaps = 0;
        partition(dup1);
        size_t swaps1 = s_actual_swaps;

        // Method #2
        s_actual_swaps = 0;
        partition_classic(dup2);
        size_t swaps2 = s_actual_swaps;

        // Method #3
        s_actual_swaps = 0;
        partition_min_swaps(dup3);
        size_t swaps3 = s_actual_swaps;

        //cout << "swaps1 #: " << swaps1 << ", swaps1 classic #: " << swaps2 << endl;

        if (swaps2 < swaps1) {
            cout << "ERROR!!\n";
            break;
        }

        if (swaps3 != min_expected) {
            cout << "ERROR!!\n";
            cout << "min #: " << min_expected << ", swaps3 #: " << swaps1 << endl;
            print(v);
            break;
        }

        if (min_expected != swaps1) {
            cout << "min #: " << min_expected << ", swaps1 #: " << swaps1 << endl;
            //print(v);
            //break;
        }

        // Contents match
        if (dup1 != dup2 || dup1 != dup3) {
            cout << "ERROR!!\n";
            print(dup1);
            print(dup2);
            print(dup3);
        }
    }
    return 0;
}
