/*
pure storage buddy system bitmap

Given a complete binary tree with nodes of values of either 1 or 0, the following rules always hold:
(1) a node's value is 1 if and only if all its subtree nodes' values are 1
(2) a leaf node can have value either 1 or 0

Implement the following 2 APIs:
set_bit(offset, length), set the bits at range from offset to offset+length-1
clear_bit(offset, length), clear the bits at range from offset to offset+length-1

i.e. The tree is like:
             0
          /     \
         0        1
       /  \      /  \
      1    0    1    1
     /\   / \   / 
    1  1 1   0 1
    One representation:
    Since it's complete binary tree, the nodes can be stored in an array:
    [0,0,1,1,0,1,1,1,1,1,0,1] 

    Another representation:
    Each level is stored in a separate array. So the tree is represented as a 2d array
    [0],
    [0,1],
    [1,0,1,1],
    [1,1,1,0,1]
*/

// This is O(n^2) solution. Don't use!

#include <iostream>
#include <vector>
#include <functional>

using namespace std;

vector<vector<bool>> g_tree;

size_t parent(size_t index)
{
    return index / 2;
}

size_t pair_index(size_t index)
{
    return ((index % 2 == 0) ? (index + 1) : (index - 1));
}

void print()
{
    cout << "Begin tree printing\n";
    for (const auto &i : g_tree) {
        for (const auto &j : i) {
            cout << j << " ";
        }
        cout << endl;
    }
    cout << "End tree printing\n";
}

// Pre: tree is not empty and offset is the valid index on last level
void set_single_bit(size_t offset)
{
    int level = g_tree.size() - 1;
    while (level >= 0) {
        // Optimization:
        // No need to go up the tree further
        if (g_tree[level][offset]) {
            break;
        }

        g_tree[level][offset] = true;
        // Node on level zero doesn't have a pair_index
        if (level != 0) {
            size_t ind = pair_index(offset);
            // If we don't have a pair or the pair is true, set parent also to true
            if ((ind >= g_tree[level].size()) || g_tree[level][ind]) {
                --level;
                offset = parent(offset);
            }
        }
    }
}

// Pre: tree is not empty and offset is the valid index on last level
void clear_single_bit(size_t offset)
{
    // Potential bug: Don't use size_t for level.
    // It will wraps around will never < 0 !

    int level = g_tree.size() - 1;
    while (level >= 0) {
        // Optimization:
        // If the current node is already false, all its parents ancestors must be false.
        // So no need to set them
        if (!g_tree[level][offset]) {
            break;
        }

        g_tree[level][offset] = false;
        // Move up one level
        --level;
        offset = parent(offset);
    }
}

void update_bit(size_t offset, size_t length, bool isSet)
{
    // Bonus point!
    // Avoid duplicate code between clear_bit() and set_bit()
    std::function<void (size_t)> callbacks[] = {clear_single_bit, set_single_bit};

    if (g_tree.empty()) {
        return;
    }

    // Bonus point!
    // Make sure we don't access nodes out-of-range
    offset = std::min(offset, g_tree.back().size() - 1);
    length = std::min(length, g_tree.back().size() - offset);

    for (size_t i = 0; i < length; ++i) {
        callbacks[isSet](offset + i);
    }
}

// offset: zero-based
void clear_bit(size_t offset, size_t length)
{
    update_bit(offset, length, false);
}

void set_bit(size_t offset, size_t length)
{
    update_bit(offset, length, true);
}

int main()
{
    g_tree = vector<vector<bool>> {
                                    {0},
                                    {0,1},
                                    {1,0,1,1},
                                    {1,1,1,0,1}
                                  };
    size_t offset = 4, length = 10;
    clear_bit(offset, length);
    print();

    set_bit(offset, length);
    print();

    return 0;
}
