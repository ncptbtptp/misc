Pure storage buddy system bitmap

Given a complete binary tree with nodes of values of either 1 or 0, the following rules always hold:
(1) a node's value is 1 if and only if all its subtree nodes' values are 1
(2) a leaf node can have value either 1 or 0
Implement the following 2 APIs:
set_bit(offset, length), set the bits at range from offset to offset+length-1
clear_bit(offset, length), clear the bits at range from offset to offset+length-1

offset: refer to the offset of the last level.

i.e. The tree is like:
             0
          /     \
         0        1
       /  \      /  \
      1    0    1    1
     /\   / \   /
    1  1 1   0 1
    Since it's complete binary tree, the nodes can be stored in an array:
    [0,0,1,1,0,1,1,1,1,1,0,1],
    or 2d array(we use this representation here):
    [
     [0],
     [0,1],
     [1,0,1,1],
     [1,1,1,0,1]
    ]

Followups:
(1) Are clear_bit() and set_bit() exactly the opposite? Prove
E.g., A -> clear_bit(offset, length) -> set_bit(offset, length) -> A'. Is tree A the same to A`?
(2) what's the time complexity of two approaches?
(3) given n nodes, how many possible trees can we have conforming to the two properties?
