/*
Importance:
Think: is this faster?
In some cases, NO!
Consider a large tree where the last level span over lots of cache lines. And only the first two
nodes and the last two nodes are "1". All other nodes are "0". What's the price of clear_bit()?
Actually,  (if nodes on the last level cross N cache lines)
With level update: there will be ~(3N - dx) cache miss.
But with normal update: ~(N + dy) cache miss. This is faster!
*/

#include <iostream>
#include <vector>
#include <functional>

using namespace std;

vector<vector<bool>> g_tree;

size_t parent(size_t index)
{
    return index / 2;
}

size_t pair_index(size_t index)
{
    return ((index % 2 == 0) ? (index + 1) : (index - 1));
}

void print()
{
    cout << "Begin tree printing\n";
    for (const auto &i : g_tree) {
        for (const auto &j : i) {
            cout << j << " ";
        }
        cout << endl;
    }
    cout << "End tree printing\n";
}

void clear_bit(size_t offset, size_t length)
{
    if (g_tree.empty()) {
        return;
    }

    if (offset + length > g_tree.back().size()) {
        return;
    }

    size_t left = offset, right = offset + length - 1;
    int level = g_tree.size() - 1;  // 0-based

    while (level >= 0) {
        // Optimization:
        // Is any node changed in this level. If all are zero already, no need to go up
        // Further optimization includes using a queue
        bool changed = false;
        for (size_t i = left; i <= right; ++i) {
            if (!g_tree[level][i]) {
                continue;
            }
            else {
                g_tree[level][i] = false;
                changed = true;
            }
        }

        if (!changed) {
            break;
        }

        left = parent(left);
        right = parent(right);
        --level;
    }
}

bool left_child(size_t level, size_t offset, size_t &leftOffset)
{
    // For nodes on last level, they don't have children as well
    if ((level >= g_tree.size() - 1) || (offset * 2 >= g_tree[level + 1].size())) {
        return false;
    }

    leftOffset = (offset * 2);
    return true;
}

bool right_child(size_t level, size_t offset, size_t &rightOffset)
{
    // For nodes on last level, they don't have children as well
    if ((level >= g_tree.size() - 1) || (offset * 2 + 1 >= g_tree[level + 1].size())) {
        return false;
    }

    rightOffset = (offset * 2 + 1);
    return true;
}

void set_bit(size_t offset, size_t length)
{
    if (g_tree.empty()) {
        return;
    }

    if ((offset + length > g_tree.back().size())) {
        return;
    }

    size_t left = offset, right = offset + length - 1;
    int level = g_tree.size() - 1; // 0-based
    while (level >= 0) {
        bool changed = false;
        for (size_t i = left; i <= right; ++i) {
            vector<bool> &this_level = g_tree[level];
            if (this_level[i]) {
                continue;
            }

            size_t left_offset = 0, right_offset = 0;
            // This automatically takes care of cases:
            // 1. Both children exist
            // 2. One doesn't exist
            // 3. Last level (neither child exist)
            if ((!left_child(level, i, left_offset) || g_tree[level + 1][left_offset]) &&
                (!right_child(level, i, right_offset) || g_tree[level + 1][right_offset])) {
                this_level[i] = true;
                changed = true;
            }
        }

        if (!changed) {
            break;
        }

        left = parent(left);
        right = parent(right);
        --level;
    }
}

int main()
{
    g_tree = vector<vector<bool>> {
                                    {0},
                                    {0,1},
                                    {1,0,1,1},
                                    {1,1,1,0,1}
                                  };
    size_t offset = 4, length = 1;
    clear_bit(offset, length);
    print();

    set_bit(offset, length);
    print();

    return 0;
}
